package com.example.demo.exception.error;

public class GenericException extends RuntimeException{

    public GenericException() {
        super("Generic error");
    }
}
