package com.example.demo.bean.response;

public class Alert {

    private String content;

    public String getContent() {
        return content;
    }

    public Alert(String content) {
        this.content = content;
    }
}
